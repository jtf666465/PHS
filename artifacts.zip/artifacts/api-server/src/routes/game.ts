import { Router, type IRouter, type Request, type Response } from "express";
import {
  GetGameStateResponse,
  GetLeaderboardResponse,
  GetNewsResponse,
  PerformGameActionBody,
  PerformGameActionResponse,
  SearchPlayersQueryParams,
  SearchPlayersResponse,
  SignInBody,
  SignInResponse,
} from "@workspace/api-zod";
import { supabaseAdmin, supabaseAuth } from "../lib/supabase";

const router: IRouter = Router();
const loginAttempts = new Map<string, { count: number; resetAt: number }>();

type JsonRecord = Record<string, unknown>;
type AuthUser = {
  id: string;
  email?: string;
  user_metadata?: Record<string, unknown>;
};

function objectOrEmpty(value: unknown): JsonRecord {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as JsonRecord)
    : {};
}

function defaultState(username: string, location: string): JsonRecord {
  return {
    player: { name: username, username, location },
    attributes: {
      health: 100,
      energy: 100,
      happiness: 72,
      charm: 28,
      iq: 50,
      fame: 0,
      actingSkill: 5,
    },
    age: { years: 16, weeks: 0 },
    schooling: { stage: "Primary", projects: [] },
    career: { contracts: [], awards: [], auditionsAttempted: 0, auditionsPassed: 0 },
    relationships: [],
    family: [],
    realEstate: [],
    luxuryItems: [],
    realTime: { lastTick: Date.now(), gameDay: 1, gameHour: 8, gameMinute: 0 },
    newsHistory: [],
  };
}

function realTimeFromAccountCreation(createdAt: unknown): JsonRecord {
  const start = typeof createdAt === "string" ? Date.parse(createdAt) : Number.NaN;
  const elapsedGameMinutes = Math.floor(Math.max(0, Date.now() - (Number.isFinite(start) ? start : Date.now())) / 30_000);
  const absoluteMinutes = 8 * 60 + elapsedGameMinutes;
  return {
    lastTick: Date.now(),
    gameDay: Math.floor(absoluteMinutes / (24 * 60)) + 1,
    gameHour: Math.floor((absoluteMinutes % (24 * 60)) / 60),
    gameMinute: absoluteMinutes % 60,
  };
}

async function userFromRequest(req: Request, res: Response): Promise<AuthUser | null> {
  const authorization = req.header("authorization");
  const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) {
    res.status(401).json({ error: "Sign in to continue." });
    return null;
  }

  const { data, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !data.user) {
    res.status(401).json({ error: "Your session has expired. Sign in again." });
    return null;
  }

  return data.user as AuthUser;
}

async function ensurePlayer(user: AuthUser): Promise<JsonRecord> {
  const { data: existing, error: selectError } = await supabaseAdmin
    .from("players")
    .select("id, email, username, location, level, xp, fame, cash, save_state, created_at, updated_at")
    .eq("id", user.id)
    .maybeSingle();
  if (selectError) throw selectError;
  if (existing) {
    const { error: bankError } = await supabaseAdmin
      .from("bank_accounts")
      .upsert({ player_id: user.id }, { onConflict: "player_id", ignoreDuplicates: true });
    if (bankError) throw bankError;
    return existing as JsonRecord;
  }

  const metadata = objectOrEmpty(user.user_metadata);
  const username =
    (typeof metadata.username === "string" && metadata.username.trim()) ||
    user.email?.split("@")[0] ||
    `player_${user.id.slice(0, 8)}`;
  const { data, error } = await supabaseAdmin
    .from("players")
    .insert({
      id: user.id,
      email: user.email ?? "",
      username,
      location: "Old GRA",
      level: 1,
      xp: 0,
      fame: 0,
      cash: 5000,
      save_state: defaultState(username, "Old GRA"),
    })
    .select("id, email, username, location, level, xp, fame, cash, save_state, created_at, updated_at")
    .single();
  if (error) throw error;
  const { error: bankError } = await supabaseAdmin
    .from("bank_accounts")
    .upsert({ player_id: user.id, balance: 0, loan_balance: 0 });
  if (bankError) throw bankError;
  return data as JsonRecord;
}

async function loadState(user: AuthUser): Promise<{ state: JsonRecord; updatedAt: string | null }> {
  const profile = await ensurePlayer(user);
  const { error: interestError } = await supabaseAdmin.rpc("apply_account_interest", {
    p_player_id: user.id,
  });
  if (interestError) throw interestError;
  const [{ data: bank, error: bankError }, { error: seenError }] = await Promise.all([
    supabaseAdmin
      .from("bank_accounts")
      .select("balance, loan_balance")
      .eq("player_id", user.id)
      .maybeSingle(),
    supabaseAdmin.from("players").update({ last_seen_at: new Date().toISOString() }).eq("id", user.id),
  ]);
  if (bankError) throw bankError;
  if (seenError) throw seenError;

  const username = String(profile.username ?? "Tamunoiyana");
  const location = String(profile.location ?? "Old GRA");
  const saved = objectOrEmpty(profile.save_state);
  const savedPlayer = objectOrEmpty(saved.player);
  const state: JsonRecord = {
    ...defaultState(username, location),
    ...saved,
    realTime: realTimeFromAccountCreation(profile.created_at),
    player: {
      ...savedPlayer,
      id: profile.id,
      name: username,
      username,
      location,
      level: Number(profile.level ?? 1),
      xp: Number(profile.xp ?? 0),
      fame: Number(profile.fame ?? 0),
      cash: Number(profile.cash ?? 0),
      bank: Number(bank?.balance ?? 0),
      loan: Number(bank?.loan_balance ?? 0),
    },
  };
  return {
    state,
    updatedAt: typeof profile.updated_at === "string" ? profile.updated_at : null,
  };
}

function publicProfile(row: JsonRecord, now = Date.now()): JsonRecord {
  const lastSeen = typeof row.last_seen_at === "string" ? Date.parse(row.last_seen_at) : 0;
  return {
    id: String(row.id),
    username: String(row.username ?? "Player"),
    level: Number(row.level ?? 1),
    fame: Number(row.fame ?? 0),
    location: String(row.location ?? "Old GRA"),
    isOnline: now - lastSeen < 5 * 60 * 1000,
  };
}

router.post("/auth/sign-in", async (req, res): Promise<void> => {
  const parsed = SignInBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const address = req.ip ?? "unknown";
  const now = Date.now();
  const attempts = loginAttempts.get(address);
  if (attempts && attempts.resetAt > now && attempts.count >= 10) {
    res.status(429).json({ error: "Too many sign-in attempts. Try again shortly." });
    return;
  }
  if (!attempts || attempts.resetAt <= now) {
    loginAttempts.set(address, { count: 1, resetAt: now + 60_000 });
  } else {
    attempts.count += 1;
  }

  const identifier = parsed.data.identifier.trim();
  let email = identifier;
  if (!identifier.includes("@")) {
    const { data: player, error: lookupError } = await supabaseAdmin
      .from("players")
      .select("email")
      .ilike("username", identifier)
      .maybeSingle();
    if (lookupError) {
      req.log.error({ err: lookupError }, "Username sign-in lookup failed");
      res.status(503).json({ error: "Sign-in is temporarily unavailable." });
      return;
    }
    if (!player?.email) {
      res.status(401).json({ error: "Invalid username or password." });
      return;
    }
    email = player.email;
  }
  const { data, error } = await supabaseAuth.auth.signInWithPassword({
    email,
    password: parsed.data.password,
  });
  if (error || !data.session || !data.user) {
    res.status(401).json({ error: "Invalid email/username or password." });
    return;
  }
  const response = {
    access_token: data.session.access_token,
    refresh_token: data.session.refresh_token,
    token_type: data.session.token_type,
    expires_in: data.session.expires_in,
    user: {
      id: data.user.id,
      email: data.user.email,
      user_metadata: data.user.user_metadata,
    },
  };
  res.json(SignInResponse.parse(response));
});

router.get("/game/state", async (req, res): Promise<void> => {
  const user = await userFromRequest(req, res);
  if (!user) return;
  const result = await loadState(user);
  res.json(GetGameStateResponse.parse(result));
});

router.post("/game/actions", async (req, res): Promise<void> => {
  const user = await userFromRequest(req, res);
  if (!user) return;
  const parsed = PerformGameActionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const action = parsed.data;
  const { data: result, error } = await supabaseAdmin.rpc("perform_game_action", {
    p_player_id: user.id,
    p_action: action.action,
    p_amount: action.amount ?? null,
    p_location: action.location ?? null,
    p_target_id: action.targetId ?? null,
    p_choice: action.choice ?? null,
  });
  if (error) {
    const message = error.message || "That action could not be completed.";
    const isGameRuleError = error.code === "P0001";
    const status = isGameRuleError ? (/not found/i.test(message) ? 404 : 400) : 500;
    if (status === 500) req.log.error({ err: error }, "Game action RPC failed");
    res.status(status).json({ error: status === 500 ? "That action could not be completed." : message });
    return;
  }
  const payload = objectOrEmpty(result);
  if (payload.error) {
    res.status(400).json({ error: String(payload.error) });
    return;
  }
  const snapshot = await loadState(user);
  res.json(
    PerformGameActionResponse.parse({
      ...snapshot,
      message: String(payload.message ?? "Action complete."),
      result: objectOrEmpty(payload.result),
    }),
  );
});

router.get("/players/search", async (req, res): Promise<void> => {
  const user = await userFromRequest(req, res);
  if (!user) return;
  const parsed = SearchPlayersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const query = parsed.data.q.trim().replace(/[%_]/g, "");
  if (query.length < 2) {
    res.json(SearchPlayersResponse.parse({ players: [] }));
    return;
  }
  const { data, error } = await supabaseAdmin
    .from("players")
    .select("id, username, level, fame, location, last_seen_at")
    .neq("id", user.id)
    .ilike("username", `%${query}%`)
    .order("fame", { ascending: false })
    .limit(12);
  if (error) throw error;
  res.json(SearchPlayersResponse.parse({ players: (data ?? []).map((row) => publicProfile(row as JsonRecord)) }));
});

router.get("/leaderboard", async (_req, res): Promise<void> => {
  const { data, error } = await supabaseAdmin
    .from("players")
    .select("id, username, level, fame, location, last_seen_at")
    .order("fame", { ascending: false })
    .order("level", { ascending: false })
    .limit(25);
  if (error) throw error;
  res.json(GetLeaderboardResponse.parse({ players: (data ?? []).map((row) => publicProfile(row as JsonRecord)) }));
});

router.get("/news", async (_req, res): Promise<void> => {
  const { data, error } = await supabaseAdmin
    .from("game_news")
    .select("id, headline, category, created_at")
    .order("created_at", { ascending: false })
    .limit(30);
  const schemaNotReady = error?.code === "42P01" || error?.code === "PGRST205";
  if (error && !schemaNotReady) throw error;
  const events = (data ?? []).map((row) => ({
    id: String(row.id),
    headline: String(row.headline),
    category: String(row.category),
    createdAt: String(row.created_at),
  }));
  const { getShuffledWorldNews } = await import("../lib/world-news");
  const items = [...events, ...getShuffledWorldNews()];
  res.json(GetNewsResponse.parse({ items }));
});

export default router;
