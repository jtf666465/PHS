import { useEffect, useMemo, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import {
  Activity, ArrowDownToLine, ArrowLeftRight, ArrowRight, ArrowUpFromLine, Banknote,
  BriefcaseBusiness, ChevronRight, CircleHelp, GraduationCap, Landmark,
  MapPin, Menu, Mic2, Newspaper, Search, Settings, Shield, SlidersHorizontal,
  TrainFront, Users, Wallet, X,
} from "lucide-react";
import { Link, Route, Router as WouterRouter, Switch, useLocation } from "wouter";
import {
  getGetGameStateQueryKey, getGetLeaderboardQueryKey, getGetNewsQueryKey,
  getSearchPlayersQueryKey, setAuthTokenGetter, useGetGameState, useGetLeaderboard,
  useGetNews, usePerformGameAction, useSearchPlayers, useSignIn,
} from "@workspace/api-client-react";
import type { GameActionInput, GameActionInputLocation, PlayerProfile } from "@workspace/api-client-react";
import { supabase } from "@/lib/supabase";

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } } });
const tokenKey = "harbor-syndicate-api-token";
setAuthTokenGetter(async () => {
  if (supabase) {
    const { data } = await supabase.auth.getSession();
    if (data.session?.access_token) return data.session.access_token;
  }
  return typeof localStorage === "undefined" ? null : localStorage.getItem(tokenKey);
});
const locations: GameActionInputLocation[] = [
  "Old GRA", "Trans Amadi", "Mile 1-3 Diobu", "Choba", "D-Line", "Woji", "Lagos Hub", "Abuja Hub",
];
const hubs = [
  { name: "Education", key: "school", icon: GraduationCap, copy: "Build credentials at the institutions that shape the city's next generation." },
  { name: "Career", key: "career", icon: BriefcaseBusiness, copy: "Find work, earn a reputation, and move through Port Harcourt's professional circles." },
  { name: "Rehearsal", key: "rehearsal", icon: Activity, copy: "Put in disciplined practice before the next opportunity arrives." },
  { name: "Business", key: "business", icon: Landmark, copy: "Keep an eye on the city's commercial corridors and your existing interests." },
  { name: "Voice-over", key: "voice-over", icon: Mic2, copy: "Make your voice heard in the rooms where deals and stories are made." },
];

type LooseState = Record<string, unknown>;
function record(value: unknown): LooseState { return value && typeof value === "object" ? value as LooseState : {}; }
function read(state: LooseState, ...keys: string[]): unknown {
  for (const key of keys) if (state[key] !== undefined && state[key] !== null) return state[key];
  return undefined;
}
function display(value: unknown, prefix = ""): string {
  if (typeof value === "number") return `${prefix}${new Intl.NumberFormat("en-NG", { maximumFractionDigits: 0 }).format(value)}`;
  if (typeof value === "string" && value.trim()) return `${prefix}${value}`;
  return "—";
}
function numberValue(value: unknown): number | undefined {
  return typeof value === "number" && Number.isFinite(value) ? value : undefined;
}
function getMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (error && typeof error === "object" && "message" in error) return String(error.message);
  return "The request could not be completed. Try again.";
}

function clockSnapshot(realTime: LooseState, now: number) {
  const lastTick = numberValue(realTime.lastTick);
  const day = numberValue(realTime.gameDay);
  const hour = numberValue(realTime.gameHour);
  const minute = numberValue(realTime.gameMinute);
  if (lastTick === undefined || day === undefined || hour === undefined || minute === undefined) return null;
  const elapsedGameMinutes = Math.max(0, Math.floor((now - lastTick) / 30_000));
  const absoluteMinutes = (day - 1) * 24 * 60 + hour * 60 + minute + elapsedGameMinutes;
  return {
    lastTick: now,
    gameDay: Math.floor(absoluteMinutes / (24 * 60)) + 1,
    gameHour: Math.floor((absoluteMinutes % (24 * 60)) / 60),
    gameMinute: absoluteMinutes % 60,
  };
}

function formatClock(realTime: LooseState, now: number) {
  const snapshot = clockSnapshot(realTime, now);
  if (!snapshot) return null;
  const hour12 = snapshot.gameHour % 12 || 12;
  const meridiem = snapshot.gameHour >= 12 ? "PM" : "AM";
  return {
    ...snapshot,
    label: `${String(hour12).padStart(2, "0")}:${String(snapshot.gameMinute).padStart(2, "0")} ${meridiem}`,
    dayPart: snapshot.gameHour >= 6 && snapshot.gameHour < 18 ? "DAY" : "NIGHT",
  };
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <Game />
      </WouterRouter>
    </QueryClientProvider>
  );
}

function Game() {
  const queryClientInstance = useQueryClient();
  const signIn = useSignIn();
  const [location, setLocation] = useLocation();
  const [authenticated, setAuthenticated] = useState(() => Boolean(localStorage.getItem(tokenKey)));
  const [username, setUsername] = useState(() => localStorage.getItem("harbor-syndicate-name") || "PLAYER");
  const [authMode, setAuthMode] = useState<"sign-in" | "register">("sign-in");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerView, setDrawerView] = useState<"menu" | "settings" | "news" | "help">("menu");
  const [authError, setAuthError] = useState("");
  const [authNotice, setAuthNotice] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [selectedHub, setSelectedHub] = useState("school");
  const [searchText, setSearchText] = useState("");
  const [actionFeedback, setActionFeedback] = useState("");
  const [soundEnabled, setSoundEnabled] = useState(true);

  useEffect(() => {
    if (!supabase) return;
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.access_token) {
        localStorage.setItem(tokenKey, session.access_token);
        const name = String(session.user.user_metadata?.username || session.user.email?.split("@")[0] || "PLAYER");
        localStorage.setItem("harbor-syndicate-name", name);
        setUsername(name);
        setAuthenticated(true);
      }
    });
    void supabase.auth.getSession().then(({ data }) => {
      if (data.session?.access_token) {
        localStorage.setItem(tokenKey, data.session.access_token);
        const name = String(data.session.user.user_metadata?.username || data.session.user.email?.split("@")[0] || "PLAYER");
        localStorage.setItem("harbor-syndicate-name", name);
        setUsername(name);
        setAuthenticated(true);
      }
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  const gameQuery = useGetGameState({ query: { enabled: authenticated, queryKey: getGetGameStateQueryKey() } });
  const performAction = usePerformGameAction();
  const searchParams = useMemo(() => ({ q: searchText.trim() }), [searchText]);
  const playersQuery = useSearchPlayers(searchParams, {
    query: { enabled: authenticated && searchParams.q.length >= 2, queryKey: getSearchPlayersQueryKey(searchParams) },
  });
  const leaderboardQuery = useGetLeaderboard({
    query: { enabled: authenticated && location === "/syndicate", queryKey: getGetLeaderboardQueryKey() },
  });
  const newsQuery = useGetNews({
    query: { enabled: authenticated, queryKey: getGetNewsQueryKey() },
  });

  const state = record(gameQuery.data?.state);
  const player = record(read(state, "player", "profile"));
  const cash = read(state, "cash", "cashBalance") ?? read(player, "cash", "cashBalance");
  const vault = read(state, "vault", "vaultBalance") ?? read(player, "vault", "bank", "bankBalance");
  const currentPlace = String(read(state, "location", "district") ?? read(player, "location") ?? "Port Harcourt");
  const currentName = String(read(player, "username", "name") ?? username);
  const level = read(state, "level") ?? read(player, "level");
  const ageData = record(read(state, "age") ?? read(player, "age"));
  const age = read(ageData, "years") ?? read(state, "age") ?? read(player, "age");
  const weeks = read(state, "weeks", "week") ?? read(ageData, "weeks") ?? read(player, "weeks");
  const xp = read(state, "xp", "experience") ?? read(player, "xp", "experience");
  const attributes = record(read(state, "attributes") ?? read(player, "attributes"));
  const health = read(state, "health") ?? read(attributes, "health");
  const energy = read(state, "energy") ?? read(attributes, "energy");
  const realTime = record(read(state, "realTime"));
  const news = newsQuery.data?.items ?? [];

  useEffect(() => {
    if (location === "/" && authenticated) setLocation("/home");
  }, [location, authenticated, setLocation]);

  function refreshGame(nextState?: LooseState) {
    if (nextState) queryClientInstance.setQueryData(getGetGameStateQueryKey(), (old: unknown) => {
      const previous = record(old);
      return { ...previous, state: nextState };
    });
    void queryClientInstance.invalidateQueries({ queryKey: getGetGameStateQueryKey() });
  }
  function runAction(input: GameActionInput) {
    setActionFeedback("");
    performAction.mutate({ data: input }, {
      onSuccess: (result) => {
        refreshGame(result.state);
        setActionFeedback(result.message || "Action recorded.");
        void queryClientInstance.invalidateQueries({ queryKey: getGetNewsQueryKey() });
      },
    });
  }
  function signOut() {
    if (supabase) void supabase.auth.signOut();
    localStorage.removeItem(tokenKey);
    localStorage.removeItem("harbor-syndicate-name");
    setAuthenticated(false);
    setUsername("PLAYER");
    setLocation("/");
    setDrawerOpen(false);
  }
  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setAuthError("");
    setAuthNotice("");
    const data = new FormData(event.currentTarget);
    const identifier = String(data.get(authMode === "register" ? "email" : "identifier") || "").trim();
    const password = String(data.get("password") || "");
    const handle = String(data.get("username") || identifier.split("@")[0]).trim();
    if (authMode === "register") {
      if (!supabase) {
        setAuthError("Account registration is unavailable until VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are configured.");
        return;
      }
      setAuthBusy(true);
      const { data: response, error } = await supabase.auth.signUp({
        email: identifier, password, options: { data: { username: handle } },
      });
      setAuthBusy(false);
      if (error) { setAuthError(error.message); return; }
      if (response.session?.access_token) {
        localStorage.setItem(tokenKey, response.session.access_token);
        localStorage.setItem("harbor-syndicate-name", handle || "PLAYER");
        setUsername(handle || "PLAYER");
        setAuthenticated(true);
        setLocation("/home");
      } else {
        setAuthNotice("Registration received. Confirm your email, then return here to sign in.");
      }
      return;
    }
    signIn.mutate({ data: { identifier, password } }, {
      onSuccess: async (session) => {
        if (supabase) {
          const { error } = await supabase.auth.setSession({
            access_token: session.access_token,
            refresh_token: session.refresh_token,
          });
          if (error) {
            setAuthError(`Signed in, but this browser could not refresh the session: ${error.message}`);
            return;
          }
        }
        localStorage.setItem(tokenKey, session.access_token);
        const freshName = String(session.user?.["username"] || session.user?.["email"]?.toString().split("@")[0] || handle || "PLAYER");
        localStorage.setItem("harbor-syndicate-name", freshName);
        setUsername(freshName);
        setAuthenticated(true);
        setLocation("/home");
        await queryClientInstance.invalidateQueries({ queryKey: getGetGameStateQueryKey() });
      },
      onError: (error) => setAuthError(getMessage(error)),
    });
  }
  function openDrawer(view: "menu" | "settings" | "news" | "help" = "menu") {
    setDrawerView(view);
    setDrawerOpen(true);
  }

  if (!authenticated) return (
    <Switch>
      <Route path="/">{() => (
        <AuthScreen mode={authMode} onMode={setAuthMode} onSubmit={submitAuth}
          busy={authBusy || signIn.isPending} error={authError} notice={authNotice} />
      )}</Route>
      <Route>{() => <AuthScreen mode={authMode} onMode={setAuthMode} onSubmit={submitAuth} busy={authBusy || signIn.isPending} error={authError} notice={authNotice} />}</Route>
    </Switch>
  );

  const pageTitle = ({ "/home": "The City", "/hubs": "Hubs", "/bank": "Bank", "/travel": "Travel", "/syndicate": "Syndicate" } as Record<string, string>)[location] || "The City";
  return (
    <div className="app-shell">
      <div className="app-layout">
        <aside className="sidebar">
          <div className="brand"><div className="brand-mark"><span>H</span></div><div className="brand-copy"><div className="brand-name">Port Harcourt<br />Syndicate</div><div className="brand-sub">TAMUNO IYANA'S UNDERGROUND</div></div></div>
          <div className="nav-caption">City ledger</div>
          <nav className="side-nav">
            <NavItem href="/home" active={location === "/home" || location === "/"} icon={<MapPin />} label="Home" />
            <NavItem href="/hubs" active={location === "/hubs"} icon={<BriefcaseBusiness />} label="Hubs" />
            <NavItem href="/bank" active={location === "/bank"} icon={<Wallet />} label="Bank" />
            <NavItem href="/travel" active={location === "/travel"} icon={<TrainFront />} label="Travel" />
            <NavItem href="/syndicate" active={location === "/syndicate"} icon={<Users />} label="Syndicate" />
          </nav>
          <div className="side-bottom">
            <div className="district-stamp"><div className="stamp-kicker">On the ground</div><div className="stamp-place">{currentPlace}</div><div className="stamp-meta">RIVERS STATE · NIGERIA</div></div>
            <button className="nav-link" onClick={() => openDrawer()} data-testid="button-open-drawer"><Settings size={16} /><span>Settings & more</span></button>
          </div>
        </aside>
        <div className="main-column">
          <header className="topbar">
            <div className="topbar-main">
              <div className="topbar-location"><MapPin /> {currentPlace} <span style={{ color: "#4f5a6d" }}>/</span> {pageTitle}</div>
              <div className="topbar-status">
                <StatusMeter label="Health" value={health} />
                <StatusMeter label="Energy" value={energy} />
                <div className="bar-money"><small>Cash</small><strong>{display(cash, "₦")}</strong></div>
                <div className="bar-money"><small>Vault</small><strong>{display(vault, "₦")}</strong></div>
              </div>
              <div className="top-actions">
                <button className="icon-button" aria-label="Open news" title="News" onClick={() => openDrawer("news")} data-testid="button-news"><Newspaper /></button>
                <button className="icon-button" aria-label="Open settings" title="Settings" onClick={() => openDrawer()} data-testid="button-settings"><Menu /></button>
                <div className="player-chip"><div className="avatar">{currentName.slice(0, 2).toUpperCase()}</div><div><strong>{currentName}</strong><small>LEVEL {display(level)}</small></div></div>
              </div>
            </div>
            <div className="topbar-secondary">
              <LiveClock realTime={realTime} />
              <NewsTicker items={news} loading={newsQuery.isLoading} error={newsQuery.isError ? getMessage(newsQuery.error) : ""} />
            </div>
          </header>
          {gameQuery.isError && <div className="page"><div className="error-box">Your game record could not be loaded. <button className="text-button" onClick={() => void gameQuery.refetch()} data-testid="button-retry-game">Retry</button></div></div>}
          <Switch>
            <Route path="/home">{() => <HomePage state={state} playerName={currentName} currentPlace={currentPlace} cash={cash} vault={vault} age={age} weeks={weeks} level={level} xp={xp} attributes={attributes} news={news} newsLoading={newsQuery.isLoading} newsError={newsQuery.isError ? getMessage(newsQuery.error) : ""} onAdvance={() => runAction({ action: "advance_week" })} actionBusy={performAction.isPending} actionError={performAction.isError ? getMessage(performAction.error) : ""} feedback={actionFeedback} onOpenNews={() => openDrawer("news")} onRetryNews={() => void newsQuery.refetch()} onOpenHubs={() => setLocation("/hubs")} gameLoading={gameQuery.isLoading} />}
            </Route>
            <Route path="/hubs">{() => <HubsPage selected={selectedHub} onSelect={setSelectedHub} currentPlace={currentPlace} state={state} onAction={runAction} busy={performAction.isPending} error={performAction.isError ? getMessage(performAction.error) : ""} feedback={actionFeedback} />}</Route>
            <Route path="/bank">{() => <BankPage cash={cash} vault={vault} onAction={runAction} busy={performAction.isPending} error={performAction.isError ? getMessage(performAction.error) : ""} feedback={actionFeedback} />}</Route>
            <Route path="/travel">{() => <TravelPage currentPlace={currentPlace} onTravel={(place) => runAction({ action: "travel", location: place })} busy={performAction.isPending} error={performAction.isError ? getMessage(performAction.error) : ""} feedback={actionFeedback} />}</Route>
            <Route path="/syndicate">{() => <SyndicatePage search={searchText} setSearch={setSearchText} currentPlace={currentPlace} searchData={playersQuery.data?.players ?? []} searchLoading={playersQuery.isLoading} searchError={playersQuery.isError ? getMessage(playersQuery.error) : ""} leaderboard={leaderboardQuery.data?.players ?? []} leaderboardLoading={leaderboardQuery.isLoading} leaderboardError={leaderboardQuery.isError ? getMessage(leaderboardQuery.error) : ""} onMug={(targetId) => runAction({ action: "mug", targetId })} busy={performAction.isPending} feedback={actionFeedback} actionError={performAction.isError ? getMessage(performAction.error) : ""} onRetrySearch={() => void playersQuery.refetch()} onRetryLeaderboard={() => void leaderboardQuery.refetch()} />}</Route>
            <Route>{() => <HomePage state={state} playerName={currentName} currentPlace={currentPlace} cash={cash} vault={vault} age={age} weeks={weeks} level={level} xp={xp} attributes={attributes} news={news} newsLoading={newsQuery.isLoading} newsError="" onAdvance={() => runAction({ action: "advance_week" })} actionBusy={performAction.isPending} actionError="" feedback="" onOpenNews={() => openDrawer("news")} onRetryNews={() => void newsQuery.refetch()} onOpenHubs={() => setLocation("/hubs")} gameLoading={gameQuery.isLoading} />}</Route>
          </Switch>
        </div>
      </div>
      <nav className="mobile-nav">
        <MobileItem href="/home" active={location === "/home" || location === "/"} icon={<MapPin />} label="Home" />
        <MobileItem href="/hubs" active={location === "/hubs"} icon={<BriefcaseBusiness />} label="Hubs" />
        <MobileItem href="/bank" active={location === "/bank"} icon={<Wallet />} label="Bank" />
        <MobileItem href="/travel" active={location === "/travel"} icon={<TrainFront />} label="Travel" />
        <button onClick={() => setLocation("/syndicate")} className={location === "/syndicate" ? "active" : ""} data-testid="nav-syndicate"><Users /><span>Syndicate</span></button>
      </nav>
      {drawerOpen && <Drawer view={drawerView} setView={setDrawerView} onClose={() => setDrawerOpen(false)} onSignOut={signOut} news={news} newsLoading={newsQuery.isLoading} newsError={newsQuery.isError ? getMessage(newsQuery.error) : ""} sound={soundEnabled} onSoundChange={setSoundEnabled} />}
    </div>
  );
}

function AuthScreen({ mode, onMode, onSubmit, busy, error, notice }: {
  mode: "sign-in" | "register";
  onMode: (mode: "sign-in" | "register") => void;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  busy: boolean; error: string; notice: string;
}) {
  const registering = mode === "register";
  return (
    <main className="auth-screen">
      <section className="auth-art">
        <div className="brand"><div className="brand-mark"><span>H</span></div><div><div className="brand-name">Port Harcourt Syndicate</div><div className="brand-sub">TAMUNO IYANA'S UNDERGROUND</div></div></div>
        <div className="auth-quote">Every move<br />leaves a <em>mark.</em></div>
        <div className="auth-bottom">Port Harcourt · Rivers State · 04°48′N 07°00′E</div>
      </section>
      <section className="auth-main">
        <div className="auth-card">
          <div className="eyebrow">A city remembers</div>
          <h1 className="auth-title">{registering ? "Make your entry" : "Return to the city"}</h1>
          <p className="auth-subtitle">{registering ? "Start building your name in Port Harcourt. Use an email address you can verify." : "Your next move is waiting. Sign in to pick up where your story stands."}</p>
          {error && <div className="error-box" role="alert" style={{ marginBottom: 14 }}>{error}</div>}
          {notice && <div className="notice" role="status" style={{ marginBottom: 14 }}>{notice}</div>}
          <form className="auth-form" onSubmit={onSubmit}>
            {registering && <div className="field"><label className="field-label" htmlFor="username">Street name</label><input id="username" className="form-control" name="username" autoComplete="username" minLength={3} maxLength={24} pattern="[A-Za-z0-9_]+" title="Use 3–24 letters, numbers, or underscores." placeholder="How the city knows you" required data-testid="input-register-username" /></div>}
            <div className="field"><label className="field-label" htmlFor={registering ? "email" : "identifier"}>{registering ? "Email address" : "Email or username"}</label><input id={registering ? "email" : "identifier"} className="form-control" name={registering ? "email" : "identifier"} type={registering ? "email" : "text"} autoComplete={registering ? "email" : "username"} placeholder={registering ? "you@example.com" : "Email address or street name"} required data-testid={registering ? "input-email" : "input-identifier"} /></div>
            <div className="field"><label className="field-label" htmlFor="password">Password</label><input id="password" className="form-control" name="password" type="password" autoComplete={registering ? "new-password" : "current-password"} minLength={8} placeholder="At least 8 characters" required data-testid="input-password" /></div>
            <button className="button" type="submit" disabled={busy} data-testid="button-auth-submit">{busy ? "One moment…" : registering ? "Create your account" : "Sign in"} <ArrowRight /></button>
          </form>
          <div className="auth-toggle">{registering ? "Already known here?" : "New to the city?"} <button onClick={() => onMode(registering ? "sign-in" : "register")} data-testid="button-switch-auth">{registering ? "Sign in" : "Register"}</button></div>
          {!registering && <div className="notice" style={{ marginTop: 22 }}>Account registration and persistent browser sessions use the configured Supabase project. Existing accounts sign in through the game API.</div>}
        </div>
      </section>
    </main>
  );
}

function NavItem({ href, active, icon, label }: { href: string; active: boolean; icon: ReactNode; label: string }) {
  return <Link href={href} className={`nav-link${active ? " active" : ""}`} data-testid={`nav-${label.toLowerCase()}`}>{icon}<span>{label}</span></Link>;
}
function MobileItem({ href, active, icon, label }: { href: string; active: boolean; icon: ReactNode; label: string }) {
  return <Link href={href} className={active ? "active" : ""} data-testid={`mobile-nav-${label.toLowerCase()}`}>{icon}<span>{label}</span></Link>;
}

function StatusMeter({ label, value }: { label: string; value: unknown }) {
  const numeric = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  const pct = Number.isFinite(numeric) ? Math.max(0, Math.min(100, numeric)) : 0;
  return <div className="bar-meter" data-testid={`status-${label.toLowerCase()}`}>
    <span>{label}</span><strong>{Number.isFinite(numeric) ? numeric : "—"}</strong>
    <div className="bar-meter-track"><i style={{ width: `${pct}%` }} /></div>
  </div>;
}

function LiveClock({ realTime }: { realTime: LooseState }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 500);
    return () => window.clearInterval(timer);
  }, []);
  const clock = formatClock(realTime, now);
  return <div className="game-clock" data-testid="game-clock">
    <span className={`clock-sun ${clock?.dayPart === "DAY" ? "is-day" : "is-night"}`} />
    <span className="clock-phase">{clock ? `${clock.dayPart} · DAY ${clock.gameDay}` : "TIME UNAVAILABLE"}</span>
    <strong>{clock?.label ?? "--:-- --"}</strong>
    <span className="clock-ratio">2× CITY TIME</span>
  </div>;
}

function NewsTicker({ items, loading, error }: { items: Array<{ id: string; headline: string; category: string; createdAt: string }>; loading: boolean; error: string }) {
  const [paused, setPaused] = useState(false);
  const headlines = items.length ? items : [];
  return <div
    className={`news-ticker${paused ? " is-paused" : ""}`}
    onPointerDown={() => setPaused(true)}
    onPointerUp={() => setPaused(false)}
    onPointerCancel={() => setPaused(false)}
    onTouchStart={() => setPaused(true)}
    onTouchEnd={() => setPaused(false)}
    aria-label="Live city headlines; press and hold to pause"
    data-testid="news-ticker"
  >
    <div className="ticker-label"><span className="ticker-live" /> LIVE WIRE</div>
    <div className="ticker-window">
      {loading ? <span className="ticker-placeholder">Tuning into city reports…</span> : error ? <span className="ticker-placeholder">The wire is temporarily quiet.</span> : headlines.length ? <div className="ticker-track">
        {[0, 1].map((copy) => <div className="ticker-content" key={copy} aria-hidden={copy === 1}>{headlines.map((item) => <span className="ticker-item" key={`${copy}-${item.id}`}><b>{item.category}</b>{item.headline}<i /></span>)}</div>)}
      </div> : <span className="ticker-placeholder">No reports on the wire.</span>}
    </div>
  </div>;
}

function PageHeading({ kicker, title, subtitle, children }: { kicker: string; title: string; subtitle: string; children?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{kicker}</div><h1 className="page-title">{title}</h1><p className="page-subtitle">{subtitle}</p></div>{children}</div>;
}
function LoadingLine() { return <div className="skeleton" style={{ width: "68%", margin: "12px auto" }} />; }
function StatCard({ label, value, foot }: { label: string; value: string; foot?: string }) {
  return <article className="card stat-card" data-testid={`stat-${label.toLowerCase().replaceAll(" ", "-")}`}><div className="stat-label">{label}</div><div className="stat-number">{value}</div>{foot && <div className="stat-foot">{foot}</div>}</article>;
}
function HomePage(props: {
  state: LooseState; playerName: string; currentPlace: string; cash: unknown; vault: unknown; age: unknown; weeks: unknown; level: unknown; xp: unknown; attributes: LooseState; news: Array<{ id: string; headline: string; category: string; createdAt: string }>; newsLoading: boolean; newsError: string;
  onAdvance: () => void; actionBusy: boolean; actionError: string; feedback: string; onOpenNews: () => void; onRetryNews: () => void; onOpenHubs: () => void; gameLoading: boolean;
}) {
  const attrList = Object.entries(props.attributes).filter(([, value]) => typeof value === "number" || typeof value === "string");
  const family = record(props.state.family);
  const relationship = read(props.state, "relationships", "relationshipStatus");
  const health = read(props.state, "health") ?? read(props.attributes, "health");
  const energy = read(props.state, "energy") ?? read(props.attributes, "energy");
  const happiness = read(props.state, "happiness") ?? read(props.attributes, "happiness");
  const yearWeek = props.weeks === undefined ? "—" : `WEEK ${display(props.weeks)}`;
  return <main className="page">
    <PageHeading kicker="Your position · live account" title="The city is in play" subtitle="A ledger of the choices, movement, and progress that shape your standing." />
    <section className="home-hero">
      <div className="hero-copy"><div className="eyebrow">Port Harcourt · {yearWeek}</div><h2 className="hero-name">{props.playerName}<br /><span className="gold">Moves quietly.</span></h2><div className="hero-line">Your name travels ahead of you. Decide what it means before the city decides for you.</div><div className="gold-rule" /><div className="mono muted" style={{ fontSize: 10, letterSpacing: ".12em", textTransform: "uppercase" }}><MapPin size={12} style={{ verticalAlign: "middle", marginRight: 6 }} />{props.currentPlace} · AGE {display(props.age)}</div></div>
      <div className="hero-stats"><div><div className="hero-stat-label">Level</div><div className="hero-stat-value gold">{display(props.level)}</div></div><div><div className="hero-stat-label">Experience</div><div className="hero-stat-value">{display(props.xp)}</div></div></div>
    </section>
    <div className="section-label">Position & resources</div>
    <section className="stats-grid">
      <StatCard label="Cash on hand" value={props.gameLoading ? "…" : display(props.cash, "₦")} foot="Available now" />
      <StatCard label="Vault" value={props.gameLoading ? "…" : display(props.vault, "₦")} foot="Held at the bank" />
      <StatCard label="Age / weeks" value={props.gameLoading ? "…" : `${display(props.age)} / ${display(props.weeks)}`} foot="Time keeps moving" />
      <StatCard label="Household" value={Object.keys(family).length ? String(Object.keys(family).length) : "—"} foot={typeof relationship === "string" ? relationship : "Relationships"} />
    </section>
    <div className="section-label">The week's pressure</div>
    <section className="home-grid">
      <article className="card panel">
        <div className="panel-head"><div className="panel-title">Attributes</div><div className="mono muted" style={{ fontSize: 9 }}>PLAYER RECORD</div></div>
        {props.gameLoading ? <><LoadingLine /><LoadingLine /><LoadingLine /></> : attrList.length ? <div className="attribute-list">{attrList.map(([name, value]) => {
          const numeric = numberValue(value);
          const percent = numeric === undefined ? 0 : Math.max(0, Math.min(100, numeric > 100 ? numeric / 10 : numeric));
          return <div className="attribute" key={name}><span className="attribute-name">{name.replace(/([A-Z])/g, " $1")}</span><div className="attribute-track"><div className="attribute-fill" style={{ width: `${percent}%` }} /></div><span className="attribute-value">{display(value)}</span></div>;
        })}</div> : <div className="empty-state">Attributes will appear here when present in your game record.</div>}
        <div className="section-label" style={{ marginTop: 25 }}>Wellbeing</div>
        <div className="stats-grid" style={{ gridTemplateColumns: "repeat(3,minmax(0,1fr))" }}>
          <StatCard label="Health" value={display(health)} />
          <StatCard label="Energy" value={display(energy)} />
          <StatCard label="Happiness" value={display(happiness)} />
        </div>
      </article>
      <article className="card panel">
        <div className="panel-head"><div className="panel-title">Street reports</div><button className="text-button" onClick={props.onOpenNews} data-testid="button-view-news">History <ChevronRight size={12} /></button></div>
        {props.newsError ? <div className="error-box">{props.newsError}<button onClick={props.onRetryNews} className="text-button" data-testid="button-retry-news">Retry</button></div> : props.newsLoading ? <><LoadingLine /><LoadingLine /></> : props.news.length ? props.news.slice(0, 3).map((item) => <NewsRow key={item.id} item={item} />) : <div className="empty-state">No reports have reached your feed.</div>}
      </article>
    </section>
    <div className="section-label">Make the next move</div>
    {props.actionError && <div className="error-box" style={{ marginBottom: 12 }}>{props.actionError}</div>}
    {props.feedback && <div className="notice" style={{ marginBottom: 12 }} role="status">{props.feedback}</div>}
    <div className="action-row">
      <button className="button" onClick={props.onAdvance} disabled={props.actionBusy || props.gameLoading} data-testid="button-advance-week">{props.actionBusy ? "Processing…" : "Advance one week"} <ArrowRight /></button>
      <button className="button secondary" onClick={props.onOpenHubs} data-testid="button-open-hubs">Visit the hubs <ArrowRight /></button>
    </div>
    <div className="save-status" role="status"><span className="save-status-dot" /> Progress saves automatically after every completed action.</div>
  </main>;
}
function NewsRow({ item }: { item: { id: string; headline: string; category: string; createdAt: string } }) {
  const date = new Date(item.createdAt);
  const when = Number.isNaN(date.getTime()) ? item.createdAt : date.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
  return <div className="news-row" data-testid={`news-${item.id}`}><div className="news-meta"><span>{item.category}</span><time>{when}</time></div><div className="news-headline">{item.headline}</div></div>;
}

function HubsPage({ selected, onSelect, currentPlace, state, onAction, busy, error, feedback }: {
  selected: string; onSelect: (hub: string) => void; currentPlace: string; state: LooseState;
  onAction: (input: GameActionInput) => void; busy: boolean; error: string; feedback: string;
}) {
  const active = hubs.find((hub) => hub.key === selected) ?? hubs[0];
  const Icon = active.icon;
  const [projectName, setProjectName] = useState("");
  const career = record(state.career);
  const schooling = record(state.schooling);
  const contracts = Array.isArray(career.contracts) ? career.contracts.map(record).slice(-3).reverse() : [];
  function submitProject(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onAction({ action: "school_project", choice: projectName.trim() || "Term project" });
    setProjectName("");
  }
  return <main className="page">
    <PageHeading kicker="Where the next chapter starts" title="City hubs" subtitle={`Every room has its own rules. Choose where to put your attention in ${currentPlace}.`} />
    <section className="hub-grid">{hubs.map((hub, index) => {
      const HubIcon = hub.icon;
      return <button className={`card hub-card${selected === hub.key ? " selected" : ""}`} key={hub.key} onClick={() => onSelect(hub.key)} data-testid={`hub-${hub.key}`}>
        <span className="hub-mark">0{index + 1} / 05</span><span className="hub-icon"><HubIcon /></span><div className="hub-title">{hub.name}</div><div className="hub-description">{hub.copy}</div>
      </button>;
    })}</section>
    <section className="card hub-detail">
      <div className="eyebrow">{currentPlace} · selected hub</div><div style={{ display: "flex", alignItems: "center", gap: 14, marginTop: 12 }}><span className="hub-icon" style={{ margin: 0 }}><Icon /></span><div><h3>{active.name}</h3><div className="muted" style={{ fontSize: 12 }}>{active.copy}</div></div></div>
      <div className="gold-rule" />
      {error && <div className="error-box" role="alert" style={{ marginBottom: 13 }}>{error}</div>}
      {feedback && <div className="notice" role="status" style={{ marginBottom: 13 }}>{feedback}</div>}
      <div className="hub-actions">
        {selected === "school" ? <>
          <div className="hub-progress"><span>Current stage</span><strong>{String(schooling.stage ?? "Primary")}</strong></div>
          <div className="action-row">
            <button className="button" disabled={busy} onClick={() => onAction({ action: "study" })} data-testid="button-study">{busy ? "Processing…" : "Study session"} <GraduationCap /></button>
            <form className="hub-project-form" onSubmit={submitProject}>
              <input className="form-control" value={projectName} onChange={(event) => setProjectName(event.target.value)} maxLength={80} placeholder="Project title (optional)" aria-label="School project title" data-testid="input-project-title" />
              <button className="button secondary" disabled={busy} type="submit" data-testid="button-school-project">{busy ? "Processing…" : "Complete project"} <ArrowRight /></button>
            </form>
          </div>
          <p className="hub-hint">Study builds knowledge and experience. A school project costs ₦500 and 12 energy.</p>
        </> : selected === "career" ? <>
          <div className="action-row">
            <button className="button" disabled={busy} onClick={() => onAction({ action: "audition", choice: "Garden City Screen Contract" })} data-testid="button-audition">{busy ? "Processing…" : "Attend audition"} <BriefcaseBusiness /></button>
            <button className="button secondary" disabled={busy} onClick={() => onAction({ action: "accept_contract", choice: "Independent film contract" })} data-testid="button-accept-contract">{busy ? "Processing…" : "Accept local contract"} <ArrowRight /></button>
          </div>
          <p className="hub-hint">Auditions use your skills and energy. Contract fees, fame, and success are recorded by the game server.</p>
          {contracts.length > 0 && <div className="hub-records">{contracts.map((contract, index) => <div className="news-row" key={`${String(contract.title)}-${index}`}><div className="news-meta"><span>{String(contract.status ?? "Career")}</span><span>{display(contract.value, "₦")}</span></div><div className="news-headline">{String(contract.title ?? "Career record")}</div></div>)}</div>}
        </> : selected === "rehearsal" ? <>
          <div className="hub-progress"><span>Acting skill</span><strong>{display(read(record(state.attributes), "actingSkill"))}</strong></div>
          <button className="button" disabled={busy} onClick={() => onAction({ action: "rehearse" })} data-testid="button-rehearse">{busy ? "Processing…" : "Begin rehearsal"} <Activity /></button>
          <p className="hub-hint">A session improves your acting skill and experience, at a cost of 12 energy.</p>
        </> : selected === "business" ? <>
          <div className="action-row"><button className="button" disabled={busy} onClick={() => onAction({ action: "business_shift" })} data-testid="button-business-shift">{busy ? "Processing…" : "Work a business shift"} <Landmark /></button></div>
          <p className="hub-hint">Earn revenue and experience from a shift. Each shift uses 10 energy.</p>
        </> : <>
          <div className="action-row"><button className="button" disabled={busy} onClick={() => onAction({ action: "voice_over" })} data-testid="button-voice-over">{busy ? "Processing…" : "Record a voice-over"} <Mic2 /></button></div>
          <p className="hub-hint">Complete a studio session to earn a fee and experience. Each session uses 8 energy.</p>
        </>}
      </div>
    </section>
  </main>;
}

function BankPage({ cash, vault, onAction, busy, error, feedback }: { cash: unknown; vault: unknown; onAction: (input: { action: "deposit" | "withdraw" | "loan"; amount: number }) => void; busy: boolean; error: string; feedback: string }) {
  function handle(event: FormEvent<HTMLFormElement>, action: "deposit" | "withdraw" | "loan") {
    event.preventDefault();
    const amount = Number(new FormData(event.currentTarget).get("amount"));
    if (Number.isFinite(amount) && amount >= 1) onAction({ action, amount });
  }
  return <main className="page">
    <PageHeading kicker="Money moves with a paper trail" title="The bank" subtitle="Keep your cash close or put it away. Borrow only when the terms make sense." />
    {error && <div className="error-box" style={{ marginBottom: 12 }}>{error}</div>}{feedback && <div className="notice" style={{ marginBottom: 12 }} role="status">{feedback}</div>}
    <section className="card bank-balance"><div><div className="balance-label">Cash in hand</div><div className="balance-value">{display(cash, "₦")}</div></div><ArrowLeftRight className="gold" /><div><div className="balance-label">Held in vault</div><div className="balance-value gold">{display(vault, "₦")}</div></div></section>
    <section className="bank-grid">
      <BankForm title="Deposit" text="Move cash from your pocket into the vault." action="deposit" button="Deposit cash" icon={<ArrowDownToLine />} busy={busy} onSubmit={handle} />
      <BankForm title="Withdraw" text="Bring funds back into circulation." action="withdraw" button="Withdraw cash" icon={<ArrowUpFromLine />} busy={busy} onSubmit={handle} />
      <BankForm title="Request a loan" text="A loan changes your position. The server determines available terms." action="loan" button="Request loan" icon={<Banknote />} busy={busy} onSubmit={handle} />
    </section>
  </main>;
}
function BankForm({ title, text, action, button, icon, busy, onSubmit }: { title: string; text: string; action: "deposit" | "withdraw" | "loan"; button: string; icon: ReactNode; busy: boolean; onSubmit: (event: FormEvent<HTMLFormElement>, action: "deposit" | "withdraw" | "loan") => void }) {
  return <form className="card bank-form" onSubmit={(event) => onSubmit(event, action)}><h3>{title}</h3><p>{text}</p><label className="field-label" htmlFor={`amount-${action}`}>Amount · NGN</label><input className="form-control" id={`amount-${action}`} name="amount" type="number" min="1" step="1" placeholder="Enter amount" required data-testid={`input-${action}-amount`} /><button className={`button${action === "loan" ? " secondary" : ""}`} type="submit" disabled={busy} style={{ marginTop: 13 }} data-testid={`button-${action}`}>{busy ? "Processing…" : button}{icon}</button></form>;
}

function TravelPage({ currentPlace, onTravel, busy, error, feedback }: { currentPlace: string; onTravel: (place: GameActionInputLocation) => void; busy: boolean; error: string; feedback: string }) {
  const districts: GameActionInputLocation[] = ["Old GRA", "Trans Amadi", "Mile 1-3 Diobu", "Choba", "D-Line", "Woji"];
  const hubsOut: GameActionInputLocation[] = ["Lagos Hub", "Abuja Hub"];
  return <main className="page">
    <PageHeading kicker="Movement changes the board" title="Travel" subtitle="Cross districts, leave your usual circles, and decide how far the name should travel." />
    {error && <div className="error-box" style={{ marginBottom: 12 }}>{error}</div>}{feedback && <div className="notice" style={{ marginBottom: 12 }} role="status">{feedback}</div>}
    <div className="section-label">Port Harcourt · districts</div>
    <section className="travel-grid">{districts.map((place, index) => <Destination key={place} place={place} index={index} current={currentPlace} busy={busy} onTravel={onTravel} />)}</section>
    <div className="section-label">Beyond the city</div>
    <section className="travel-grid">{hubsOut.map((place, index) => <Destination key={place} place={place} index={index + 6} current={currentPlace} busy={busy} onTravel={onTravel} regional />)}</section>
  </main>;
}
function Destination({ place, index, current, busy, onTravel, regional = false }: { place: GameActionInputLocation; index: number; current: string; busy: boolean; onTravel: (place: GameActionInputLocation) => void; regional?: boolean }) {
  const isCurrent = current === place;
  return <article className="card destination"><div><div className="destination-meta">{regional ? "Intercity hub" : `District · ${String(index + 1).padStart(2, "0")}`}</div><div className="destination-name">{place}</div></div><button className={isCurrent ? "button secondary" : "button"} disabled={busy || isCurrent} onClick={() => onTravel(place)} data-testid={`button-travel-${place.toLowerCase().replaceAll(" ", "-")}`}>{isCurrent ? "Current district" : busy ? "Moving…" : "Travel here"}{!isCurrent && <ArrowRight />}</button></article>;
}

function SyndicatePage(props: {
  search: string; setSearch: (query: string) => void; currentPlace: string; searchData: PlayerProfile[]; searchLoading: boolean; searchError: string;
  leaderboard: PlayerProfile[]; leaderboardLoading: boolean; leaderboardError: string; onMug: (id: string) => void; busy: boolean; feedback: string; actionError: string; onRetrySearch: () => void; onRetryLeaderboard: () => void;
}) {
  return <main className="page">
    <PageHeading kicker="Names in the same city" title="The syndicate" subtitle="Find players by username and see who has built standing across the network." />
    {props.actionError && <div className="error-box" style={{ marginBottom: 12 }}>{props.actionError}</div>}{props.feedback && <div className="notice" style={{ marginBottom: 12 }} role="status">{props.feedback}</div>}
    <section className="card panel" style={{ marginBottom: 15 }}>
      <div className="panel-head"><div className="panel-title">Player search</div><span className="eyebrow">Name only</span></div>
      <div style={{ position: "relative" }}><Search size={16} style={{ position: "absolute", left: 13, top: 14, color: "#788499" }} /><input className="form-control" style={{ paddingLeft: 39 }} type="search" value={props.search} onChange={(event) => props.setSearch(event.target.value)} placeholder="Search username · minimum 2 characters" data-testid="input-player-search" /></div>
      <div className="notice" style={{ marginTop: 13 }}>You can only interact with players in your current district. Travel to their location first.</div>
      <div style={{ marginTop: 11 }}>
        {props.search.length < 2 ? <div className="empty-state">Enter at least two characters to find players.</div> : props.searchLoading ? <><LoadingLine /><LoadingLine /></> : props.searchError ? <div className="error-box">{props.searchError}<button className="text-button" onClick={props.onRetrySearch} data-testid="button-retry-search">Retry</button></div> : props.searchData.length ? props.searchData.map((player) => <PlayerRow key={player.id} player={player} currentPlace={props.currentPlace} action="mug" busy={props.busy} onMug={props.onMug} />) : <div className="empty-state">No players found for that name.</div>}
      </div>
    </section>
    <section className="card panel">
      <div className="panel-head"><div className="panel-title">Standing across the city</div><div className="eyebrow">Leaderboard</div></div>
      {props.leaderboardError ? <div className="error-box">{props.leaderboardError}<button className="text-button" onClick={props.onRetryLeaderboard} data-testid="button-retry-leaderboard">Retry</button></div> : props.leaderboardLoading ? <><LoadingLine /><LoadingLine /><LoadingLine /></> : props.leaderboard.length ? props.leaderboard.map((player, index) => <PlayerRow key={player.id} player={player} rank={index + 1} />) : <div className="empty-state">No leaderboard entries are available.</div>}
    </section>
  </main>;
}
function PlayerRow({ player, rank, action, busy, onMug, currentPlace }: { player: PlayerProfile; rank?: number; action?: "mug"; busy?: boolean; onMug?: (id: string) => void; currentPlace?: string }) {
  const nearby = !currentPlace || player.location === currentPlace;
  return <div className="player-row" data-testid={`player-${player.id}`}>
    {rank ? <div className="rank">{String(rank).padStart(2, "0")}</div> : <div className="player-initial">{player.username.slice(0, 2).toUpperCase()}</div>}
    <div><div className="player-name">{player.username}</div><div className="player-meta"><span className={`online-dot${player.isOnline ? " on" : ""}`} />{player.isOnline ? "Online" : "Away"} · {player.location}</div></div>
    <div className="mono muted" style={{ fontSize: 10, whiteSpace: "nowrap" }}>LVL {player.level} · FAME {player.fame}</div>
    {action && <div className="player-action-wrap"><button className="button danger player-action" disabled={busy || !nearby} title={nearby ? "Attempt an interaction with this player" : `Travel to ${player.location} to interact`} onClick={() => onMug?.(player.id)} data-testid={`button-mug-${player.id}`}>{!nearby ? "Out of district" : busy ? "Working…" : "Attempt mugging"}<Shield /></button>{!nearby && <small className="player-distance-hint">Target is in {player.location}. Travel there to interact.</small>}</div>}
  </div>;
}

function Drawer({ view, setView, onClose, onSignOut, news, newsLoading, newsError, sound, onSoundChange }: {
  view: "menu" | "settings" | "news" | "help"; setView: (view: "menu" | "settings" | "news" | "help") => void; onClose: () => void; onSignOut: () => void;
  news: Array<{ id: string; headline: string; category: string; createdAt: string }>; newsLoading: boolean; newsError: string; sound: boolean; onSoundChange: (value: boolean) => void;
}) {
  const title = view === "menu" ? "Field desk" : view === "help" ? "Rules of the city" : view === "news" ? "News history" : "Settings";
  return <div className="drawer-backdrop" onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <aside className="drawer" role="dialog" aria-modal="true" aria-label={title}>
      <div className="drawer-head"><div><div className="eyebrow">Port Harcourt Syndicate</div><div className="drawer-title">{title}</div></div><button className="icon-button" onClick={onClose} aria-label="Close panel" data-testid="button-close-drawer"><X /></button></div>
      {view === "menu" ? <div>
        <button className="drawer-item" onClick={() => setView("settings")} data-testid="drawer-settings"><Settings /> Settings <ChevronRight style={{ marginLeft: "auto" }} /></button>
        <button className="drawer-item" onClick={() => setView("news")} data-testid="drawer-news"><Newspaper /> News history <ChevronRight style={{ marginLeft: "auto" }} /></button>
        <button className="drawer-item" onClick={() => setView("help")} data-testid="drawer-help"><CircleHelp /> Help & rules <ChevronRight style={{ marginLeft: "auto" }} /></button>
        <div className="drawer-content" style={{ marginTop: 24 }}><div className="notice">Your completed actions are saved to your player record automatically.</div><button className="drawer-item" onClick={onSignOut} style={{ color: "#ec8d94", marginTop: 12 }} data-testid="button-sign-out"><ArrowRight /> Sign out</button></div>
      </div> : view === "settings" ? <div className="drawer-content">
        <div className="drawer-item" style={{ justifyContent: "space-between" }}><span style={{ display: "flex", gap: 12, alignItems: "center" }}><SlidersHorizontal className="gold" /> Interface sound preference</span><input type="checkbox" checked={sound} onChange={(event) => onSoundChange(event.target.checked)} aria-label="Enable interface sound" data-testid="toggle-sound" /></div>
        <div className="notice" style={{ marginTop: 17 }}>Your game progress is held by the game server. Supabase browser sessions persist on this device.</div>
        <button className="drawer-item" onClick={() => setView("menu")} data-testid="button-settings-back"><ArrowRight style={{ transform: "rotate(180deg)" }} /> Back to menu</button>
      </div> : view === "news" ? <div className="drawer-content">
        {newsError ? <div className="error-box">{newsError}</div> : newsLoading ? <><LoadingLine /><LoadingLine /></> : news.length ? news.map((item) => <NewsRow key={item.id} item={item} />) : <div className="empty-state">There are no reports in the record yet.</div>}
        <button className="drawer-item" onClick={() => setView("menu")} data-testid="button-news-back"><ArrowRight style={{ transform: "rotate(180deg)" }} /> Back to menu</button>
      </div> : <div className="drawer-content">
        <div className="notice" style={{ marginBottom: 13 }}>The city runs on consequence. Actions are submitted to the game server, which owns eligibility, costs, rewards, and the authoritative player record.</div>
        <div className="news-row"><div className="news-meta"><span>Progression</span></div><div className="news-headline">Advance a week from Home to move your game time forward.</div></div>
        <div className="news-row"><div className="news-meta"><span>Money</span></div><div className="news-headline">Use the Bank for deposits, withdrawals, and loan requests.</div></div>
        <div className="news-row"><div className="news-meta"><span>Movement</span></div><div className="news-headline">Travel between Port Harcourt districts, Lagos, and Abuja.</div></div>
        <div className="news-row"><div className="news-meta"><span>Syndicate</span></div><div className="news-headline">Search by username. A mugging attempt is subject to server-side proximity rules.</div></div>
        <button className="drawer-item" onClick={() => setView("menu")} data-testid="button-help-back"><ArrowRight style={{ transform: "rotate(180deg)" }} /> Back to menu</button>
      </div>}
    </aside>
  </div>;
}

export default App;
