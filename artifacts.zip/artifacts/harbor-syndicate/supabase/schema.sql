create extension if not exists pgcrypto;

create table if not exists public.players (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  username text not null,
  location text not null default 'Old GRA',
  level integer not null default 1 check (level >= 1),
  xp integer not null default 0 check (xp >= 0),
  fame integer not null default 0 check (fame >= 0),
  cash numeric(14, 2) not null default 5000 check (cash >= 0),
  save_state jsonb not null default '{}'::jsonb,
  last_seen_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint players_location_valid check (
    location in ('Old GRA', 'Trans Amadi', 'Mile 1-3 Diobu', 'Choba', 'D-Line', 'Woji', 'Lagos Hub', 'Abuja Hub')
  )
);

create unique index if not exists players_email_ci_idx on public.players (lower(email));
create unique index if not exists players_username_ci_idx on public.players (lower(username));
create index if not exists players_leaderboard_idx on public.players (fame desc, level desc);

create table if not exists public.bank_accounts (
  player_id uuid primary key references public.players(id) on delete cascade,
  balance numeric(14, 2) not null default 0 check (balance >= 0),
  loan_balance numeric(14, 2) not null default 0 check (loan_balance >= 0),
  last_interest_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.game_news (
  id uuid primary key default gen_random_uuid(),
  headline text not null,
  category text not null,
  created_at timestamptz not null default now()
);

alter table public.players enable row level security;
alter table public.bank_accounts enable row level security;
alter table public.game_news enable row level security;

drop policy if exists "Players can read their own profile" on public.players;
create policy "Players can read their own profile"
  on public.players for select to authenticated using (auth.uid() = id);
drop policy if exists "Players can read their own bank account" on public.bank_accounts;
create policy "Players can read their own bank account"
  on public.bank_accounts for select to authenticated using (auth.uid() = player_id);
drop policy if exists "Game news is readable" on public.game_news;
create policy "Game news is readable"
  on public.game_news for select to authenticated, anon using (true);

create or replace function public.initialize_syndicate_player()
returns trigger
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  candidate text;
begin
  candidate := coalesce(
    nullif(trim(new.raw_user_meta_data ->> 'username'), ''),
    split_part(coalesce(new.email, 'player'), '@', 1)
  );
  candidate := left(regexp_replace(candidate, '[^A-Za-z0-9_]', '', 'g'), 24);
  if length(candidate) < 3 then
    candidate := 'player_' || left(replace(new.id::text, '-', ''), 8);
  end if;

  insert into public.players (id, email, username, save_state)
  values (
    new.id,
    coalesce(new.email, ''),
    candidate,
    jsonb_build_object(
      'player', jsonb_build_object('name', candidate, 'username', candidate, 'location', 'Old GRA'),
      'attributes', jsonb_build_object('health', 100, 'energy', 100, 'happiness', 72, 'charm', 28, 'iq', 50, 'actingSkill', 5),
      'age', jsonb_build_object('years', 16, 'weeks', 0),
      'schooling', jsonb_build_object('stage', 'Primary', 'projects', '[]'::jsonb),
      'career', jsonb_build_object('contracts', '[]'::jsonb, 'awards', '[]'::jsonb)
    )
  )
  on conflict (id) do nothing;

  insert into public.bank_accounts (player_id)
  values (new.id)
  on conflict (player_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created_syndicate on auth.users;
create trigger on_auth_user_created_syndicate
  after insert on auth.users
  for each row execute function public.initialize_syndicate_player();

create or replace function public.apply_account_interest(p_player_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  account public.bank_accounts%rowtype;
  elapsed_days integer;
begin
  select * into account
  from public.bank_accounts
  where player_id = p_player_id
  for update;

  if not found then
    return;
  end if;

  elapsed_days := least(
    365,
    greatest(0, floor(extract(epoch from (now() - account.last_interest_at)) / 43200)::integer)
  );

  if elapsed_days > 0 then
    update public.bank_accounts
    set balance = round(balance * power(1.05::numeric, elapsed_days), 2),
        loan_balance = round(loan_balance * power(1.10::numeric, elapsed_days), 2),
        last_interest_at = account.last_interest_at + make_interval(hours => elapsed_days * 12),
        updated_at = now()
    where player_id = p_player_id;
  end if;
end;
$$;

create or replace function public.perform_game_action(
  p_player_id uuid,
  p_action text,
  p_amount numeric default null,
  p_location text default null,
  p_target_id uuid default null,
  p_choice text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  player_row public.players%rowtype;
  target_row public.players%rowtype;
  bank_row public.bank_accounts%rowtype;
  amount_value numeric(14, 2);
  travel_cost numeric(14, 2);
  mug_success boolean;
  stolen numeric(14, 2);
  chance integer;
  weeks_total integer;
  years_total integer;
  week_number integer;
  attributes jsonb;
  schooling jsonb;
  career jsonb;
  activities jsonb;
  activity_success boolean;
  cash_reward numeric(14, 2);
  activity_chance integer;
  choice_value text;
  result_value jsonb := '{}'::jsonb;
  message_value text;
begin
  if p_action not in (
    'advance_week', 'deposit', 'withdraw', 'loan', 'travel', 'mug',
    'study', 'school_project', 'rehearse', 'audition', 'voice_over',
    'business_shift', 'accept_contract', 'buy_item', 'buy_property',
    'relationship', 'family_event'
  ) then
    raise exception 'This action is not available.';
  end if;

  if p_action = 'mug' and p_target_id is not null then
    perform 1
    from public.players
    where id in (p_player_id, p_target_id)
    order by id
    for update;
  else
    perform 1 from public.players where id = p_player_id for update;
  end if;

  select * into player_row from public.players where id = p_player_id;
  if not found then
    raise exception 'Player profile not found.';
  end if;

  perform public.apply_account_interest(p_player_id);
  select * into bank_row from public.bank_accounts where player_id = p_player_id for update;

  if p_action in ('deposit', 'withdraw', 'loan', 'buy_item', 'buy_property') then
    amount_value := round(coalesce(p_amount, 0), 2);
    if amount_value <= 0 then
      raise exception 'Enter an amount greater than zero.';
    end if;
    if amount_value > 1000000000 then
      raise exception 'That amount is outside the permitted range.';
    end if;
  end if;
  choice_value := left(trim(coalesce(p_choice, '')), 80);

  if p_action = 'advance_week' then
    attributes := coalesce(player_row.save_state -> 'attributes', '{}'::jsonb);
    weeks_total :=
      coalesce((player_row.save_state -> 'age' ->> 'years')::integer, 16) * 52
      + coalesce((player_row.save_state -> 'age' ->> 'weeks')::integer, 0)
      + 1;
    years_total := weeks_total / 52;
    week_number := weeks_total % 52;
    update public.players
    set save_state = jsonb_set(
          jsonb_set(
            coalesce(save_state, '{}'::jsonb),
            '{age}',
            coalesce(save_state -> 'age', '{}'::jsonb) ||
              jsonb_build_object('years', years_total, 'weeks', week_number),
            true
          ),
          '{attributes}',
          attributes || jsonb_build_object(
            'energy', least(100, coalesce((attributes ->> 'energy')::integer, 80) + 28),
            'health', least(100, coalesce((attributes ->> 'health')::integer, 100) + 2),
            'happiness', greatest(0, least(100, coalesce((attributes ->> 'happiness')::integer, 70) + 2))
          ),
          true
        ),
        cash = cash + 500,
        updated_at = now()
    where id = p_player_id;
    message_value := 'A week passes. Your allowance and energy recover.';
    result_value := jsonb_build_object('allowance', 500, 'weeksAdvanced', 1);

  elsif p_action = 'deposit' then
    if player_row.cash < amount_value then
      raise exception 'Not enough pocket cash for that deposit.';
    end if;
    update public.players set cash = cash - amount_value, updated_at = now() where id = p_player_id;
    update public.bank_accounts set balance = balance + amount_value, updated_at = now() where player_id = p_player_id;
    if amount_value >= 1000000 then
      insert into public.game_news (headline, category)
      values (player_row.username || ' moves a major sum into the protected central vault.', 'economy');
    end if;
    message_value := 'Deposit secured in your vault.';
    result_value := jsonb_build_object('amount', amount_value, 'protected', true);

  elsif p_action = 'withdraw' then
    if bank_row.balance < amount_value then
      raise exception 'Your vault balance is too low for that withdrawal.';
    end if;
    update public.players set cash = cash + amount_value, updated_at = now() where id = p_player_id;
    update public.bank_accounts set balance = balance - amount_value, updated_at = now() where player_id = p_player_id;
    message_value := 'Cash withdrawn from your vault.';
    result_value := jsonb_build_object('amount', amount_value);

  elsif p_action = 'loan' then
    if bank_row.loan_balance + amount_value > (10000 + (player_row.fame * 1000) + (player_row.level * 2500)) then
      raise exception 'That loan exceeds your current fame and level limit.';
    end if;
    update public.players set cash = cash + amount_value, updated_at = now() where id = p_player_id;
    update public.bank_accounts
    set loan_balance = loan_balance + amount_value, updated_at = now()
    where player_id = p_player_id;
    message_value := 'Emergency loan issued. Interest compounds daily in game time.';
    result_value := jsonb_build_object('amount', amount_value, 'dailyRate', 0.10);

  elsif p_action = 'travel' then
    if p_location is null or not (
      p_location = any(array['Old GRA', 'Trans Amadi', 'Mile 1-3 Diobu', 'Choba', 'D-Line', 'Woji', 'Lagos Hub', 'Abuja Hub'])
    ) then
      raise exception 'Choose a valid destination.';
    end if;
    if p_location = player_row.location then
      raise exception 'You are already in this location.';
    end if;
    travel_cost := case p_location when 'Lagos Hub' then 25000 when 'Abuja Hub' then 40000 else 2500 end;
    if player_row.cash < travel_cost then
      raise exception 'You do not have enough pocket cash to travel.';
    end if;
    update public.players
    set location = p_location, cash = cash - travel_cost, updated_at = now()
    where id = p_player_id;
    message_value := 'You arrived in ' || p_location || '.';
    result_value := jsonb_build_object('location', p_location, 'fare', travel_cost);

  elsif p_action = 'mug' then
    if p_target_id is null or p_target_id = p_player_id then
      raise exception 'Choose another player.';
    end if;
    select * into target_row from public.players where id = p_target_id for update;
    if not found then
      raise exception 'Target player not found.';
    end if;
    if target_row.location <> player_row.location then
      raise exception 'Target is in ' || target_row.location || '. Travel there to interact.';
    end if;
    chance := greatest(
      10,
      least(
        85,
        42 + player_row.level * 3 + player_row.fame / 25
        - coalesce((target_row.save_state -> 'attributes' ->> 'defense')::integer, 20) / 2
      )
    );
    mug_success := random() * 100 < chance;
    if mug_success then
      stolen := least(target_row.cash, greatest(100, round(target_row.cash * 0.25, 2)));
      update public.players set cash = cash - stolen, updated_at = now() where id = p_target_id;
      update public.players set cash = cash + stolen, fame = fame + 1, updated_at = now() where id = p_player_id;
      insert into public.game_news (headline, category)
      values ('A street encounter in ' || player_row.location || ' left ' || target_row.username || ' short on pocket cash.', 'street');
      message_value := 'The mugging succeeded. ' || to_char(stolen, 'FM999,999,990.00') || ' was taken from pocket cash.';
    else
      update public.players set fame = greatest(0, fame - 1), updated_at = now() where id = p_player_id;
      message_value := 'The attempt failed. The target kept their cash.';
    end if;
    result_value := jsonb_build_object('success', mug_success, 'chance', chance, 'amount', coalesce(stolen, 0), 'targetId', p_target_id);
  elsif p_action = 'study' then
    attributes := coalesce(player_row.save_state -> 'attributes', '{}'::jsonb);
    if coalesce((attributes ->> 'energy')::integer, 80) < 8 then
      raise exception 'Rest before taking on another study session.';
    end if;
    schooling := coalesce(player_row.save_state -> 'schooling', '{}'::jsonb);
    weeks_total := coalesce((schooling ->> 'studySessions')::integer, 0) + 1;
    years_total := coalesce((player_row.save_state -> 'age' ->> 'years')::integer, 16);
    schooling := schooling || jsonb_build_object(
      'stage', case when years_total >= 22 then 'Acting Academy' when years_total >= 19 then 'University' when years_total >= 17 then 'Secondary' else 'Primary' end,
      'studySessions', weeks_total
    );
    update public.players
    set save_state = jsonb_set(
          jsonb_set(coalesce(save_state, '{}'::jsonb), '{schooling}', schooling, true),
          '{attributes}',
          attributes || jsonb_build_object(
            'iq', least(100, coalesce((attributes ->> 'iq')::integer, 50) + 1),
            'energy', greatest(0, coalesce((attributes ->> 'energy')::integer, 80) - 8)
          ),
          true
        ),
        xp = xp + 20,
        level = greatest(level, 1 + floor((xp + 20)::numeric / 250)::integer),
        updated_at = now()
    where id = p_player_id;
    message_value := 'Study session complete. Your knowledge and experience increased.';
    result_value := jsonb_build_object('studySessions', weeks_total, 'schoolStage', schooling ->> 'stage');

  elsif p_action = 'school_project' then
    attributes := coalesce(player_row.save_state -> 'attributes', '{}'::jsonb);
    if coalesce((attributes ->> 'energy')::integer, 80) < 12 or player_row.cash < 500 then
      raise exception 'A project needs 12 energy and ₦500 for materials.';
    end if;
    schooling := coalesce(player_row.save_state -> 'schooling', '{}'::jsonb);
    activities := coalesce(schooling -> 'projects', '[]'::jsonb) ||
      jsonb_build_array(jsonb_build_object(
        'title', coalesce(nullif(choice_value, ''), 'Term project'),
        'completed', true,
        'completedAt', now()
      ));
    update public.players
    set save_state = jsonb_set(
          jsonb_set(coalesce(save_state, '{}'::jsonb), '{schooling}',
            schooling || jsonb_build_object('projects', activities), true),
          '{attributes}',
          attributes || jsonb_build_object('energy', greatest(0, coalesce((attributes ->> 'energy')::integer, 80) - 12)),
          true
        ),
        cash = cash - 500,
        fame = fame + 2,
        xp = xp + 40,
        level = greatest(level, 1 + floor((xp + 40)::numeric / 250)::integer),
        updated_at = now()
    where id = p_player_id;
    message_value := 'School project completed. Your work earned citywide recognition.';
    result_value := jsonb_build_object('title', coalesce(nullif(choice_value, ''), 'Term project'), 'fameEarned', 2);

  elsif p_action = 'rehearse' then
    attributes := coalesce(player_row.save_state -> 'attributes', '{}'::jsonb);
    if coalesce((attributes ->> 'energy')::integer, 80) < 12 then
      raise exception 'Rest before another rehearsal.';
    end if;
    update public.players
    set save_state = jsonb_set(
          coalesce(save_state, '{}'::jsonb),
          '{attributes}',
          attributes || jsonb_build_object(
            'actingSkill', least(100, coalesce((attributes ->> 'actingSkill')::integer, 5) + 2),
            'energy', greatest(0, coalesce((attributes ->> 'energy')::integer, 80) - 12)
          ),
          true
        ),
        xp = xp + 20,
        level = greatest(level, 1 + floor((xp + 20)::numeric / 250)::integer),
        updated_at = now()
    where id = p_player_id;
    message_value := 'Rehearsal finished. Acting skill and experience improved.';
    result_value := jsonb_build_object('skillPoints', 2, 'energyUsed', 12);

  elsif p_action = 'audition' then
    attributes := coalesce(player_row.save_state -> 'attributes', '{}'::jsonb);
    if coalesce((attributes ->> 'energy')::integer, 80) < 18 then
      raise exception 'Rest before your next audition.';
    end if;
    activity_chance := greatest(10, least(90,
      35 + coalesce((attributes ->> 'actingSkill')::integer, 5) * 2
      + coalesce((attributes ->> 'charm')::integer, 28) / 4
      + player_row.level * 2
    ));
    activity_success := random() * 100 < activity_chance;
    career := coalesce(player_row.save_state -> 'career', '{}'::jsonb);
    cash_reward := 8000 + player_row.level * 2500;
    activities := coalesce(career -> 'contracts', '[]'::jsonb);
    if activity_success then
      activities := activities || jsonb_build_array(jsonb_build_object(
        'title', coalesce(nullif(choice_value, ''), 'Garden City Screen Contract'),
        'value', cash_reward,
        'status', 'completed',
        'awardedAt', now()
      ));
      update public.players
      set save_state = jsonb_set(
            jsonb_set(coalesce(save_state, '{}'::jsonb), '{career}',
              career || jsonb_build_object(
                'contracts', activities,
                'auditionsAttempted', coalesce((career ->> 'auditionsAttempted')::integer, 0) + 1,
                'auditionsPassed', coalesce((career ->> 'auditionsPassed')::integer, 0) + 1
              ), true),
            '{attributes}',
            attributes || jsonb_build_object('energy', greatest(0, coalesce((attributes ->> 'energy')::integer, 80) - 18)),
            true
          ),
          cash = cash + cash_reward,
          fame = fame + 4,
          xp = xp + 50,
          level = greatest(level, 1 + floor((xp + 50)::numeric / 250)::integer),
          updated_at = now()
      where id = p_player_id;
      insert into public.game_news (headline, category)
      values (player_row.username || ' lands a new screen contract after an audition.', 'entertainment');
      message_value := 'You landed the role and a new film contract.';
    else
      update public.players
      set save_state = jsonb_set(
            jsonb_set(coalesce(save_state, '{}'::jsonb), '{career}',
              career || jsonb_build_object('auditionsAttempted', coalesce((career ->> 'auditionsAttempted')::integer, 0) + 1), true),
            '{attributes}',
            attributes || jsonb_build_object('energy', greatest(0, coalesce((attributes ->> 'energy')::integer, 80) - 18)),
            true
          ),
          xp = xp + 5,
          updated_at = now()
      where id = p_player_id;
      message_value := 'The casting call went to another performer. You gained experience for showing up.';
    end if;
    result_value := jsonb_build_object('success', activity_success, 'chance', activity_chance, 'contractValue', case when activity_success then cash_reward else 0 end);

  elsif p_action = 'voice_over' then
    attributes := coalesce(player_row.save_state -> 'attributes', '{}'::jsonb);
    if coalesce((attributes ->> 'energy')::integer, 80) < 8 then
      raise exception 'Rest before another voice-over session.';
    end if;
    career := coalesce(player_row.save_state -> 'career', '{}'::jsonb);
    cash_reward := 3500 + player_row.level * 500;
    update public.players
    set save_state = jsonb_set(
          jsonb_set(coalesce(save_state, '{}'::jsonb), '{career}',
            career || jsonb_build_object('voiceOverCompleted', coalesce((career ->> 'voiceOverCompleted')::integer, 0) + 1), true),
          '{attributes}',
          attributes || jsonb_build_object('energy', greatest(0, coalesce((attributes ->> 'energy')::integer, 80) - 8)),
          true
        ),
        cash = cash + cash_reward,
        xp = xp + 18,
        level = greatest(level, 1 + floor((xp + 18)::numeric / 250)::integer),
        updated_at = now()
    where id = p_player_id;
    message_value := 'Voice-over session complete. Your fee has been paid.';
    result_value := jsonb_build_object('fee', cash_reward);

  elsif p_action = 'business_shift' then
    attributes := coalesce(player_row.save_state -> 'attributes', '{}'::jsonb);
    if coalesce((attributes ->> 'energy')::integer, 80) < 10 then
      raise exception 'Rest before taking another business shift.';
    end if;
    cash_reward := 2500 + player_row.level * 500;
    update public.players
    set save_state = jsonb_set(
          coalesce(save_state, '{}'::jsonb),
          '{attributes}',
          attributes || jsonb_build_object('energy', greatest(0, coalesce((attributes ->> 'energy')::integer, 80) - 10)),
          true
        ),
        cash = cash + cash_reward,
        xp = xp + 15,
        level = greatest(level, 1 + floor((xp + 15)::numeric / 250)::integer),
        updated_at = now()
    where id = p_player_id;
    message_value := 'Business shift complete. Revenue and experience added.';
    result_value := jsonb_build_object('revenue', cash_reward);

  elsif p_action = 'accept_contract' then
    career := coalesce(player_row.save_state -> 'career', '{}'::jsonb);
    cash_reward := 10000 + player_row.level * 3000;
    activities := coalesce(career -> 'contracts', '[]'::jsonb) ||
      jsonb_build_array(jsonb_build_object(
        'title', coalesce(nullif(choice_value, ''), 'Independent film contract'),
        'value', cash_reward,
        'status', 'completed',
        'awardedAt', now()
      ));
    update public.players
    set save_state = jsonb_set(coalesce(save_state, '{}'::jsonb), '{career}',
          career || jsonb_build_object('contracts', activities), true),
        cash = cash + cash_reward,
        fame = fame + 2,
        xp = xp + 40,
        level = greatest(level, 1 + floor((xp + 40)::numeric / 250)::integer),
        updated_at = now()
    where id = p_player_id;
    insert into public.game_news (headline, category)
    values (player_row.username || ' signs a new independent film contract.', 'entertainment');
    message_value := 'Contract signed. The fee and fame are now on your record.';
    result_value := jsonb_build_object('title', coalesce(nullif(choice_value, ''), 'Independent film contract'), 'fee', cash_reward);

  elsif p_action = 'buy_item' then
    if player_row.cash < amount_value then
      raise exception 'Not enough pocket cash for that purchase.';
    end if;
    activities := coalesce(player_row.save_state -> 'luxuryItems', '[]'::jsonb) ||
      jsonb_build_array(jsonb_build_object(
        'name', coalesce(nullif(choice_value, ''), 'Personal luxury'),
        'value', amount_value,
        'purchasedAt', now()
      ));
    update public.players
    set save_state = jsonb_set(coalesce(save_state, '{}'::jsonb), '{luxuryItems}', activities, true),
        cash = cash - amount_value,
        updated_at = now()
    where id = p_player_id;
    message_value := 'Luxury item added to your collection.';
    result_value := jsonb_build_object('item', coalesce(nullif(choice_value, ''), 'Personal luxury'), 'cost', amount_value);

  elsif p_action = 'buy_property' then
    if amount_value < 100000 or player_row.cash < amount_value then
      raise exception 'Property requires at least ₦100,000 and enough pocket cash.';
    end if;
    activities := coalesce(player_row.save_state -> 'realEstate', '[]'::jsonb) ||
      jsonb_build_array(jsonb_build_object(
        'name', coalesce(nullif(choice_value, ''), 'Port Harcourt property'),
        'value', amount_value,
        'purchasedAt', now()
      ));
    update public.players
    set save_state = jsonb_set(coalesce(save_state, '{}'::jsonb), '{realEstate}', activities, true),
        cash = cash - amount_value,
        updated_at = now()
    where id = p_player_id;
    message_value := 'Property added to your holdings.';
    result_value := jsonb_build_object('property', coalesce(nullif(choice_value, ''), 'Port Harcourt property'), 'cost', amount_value);

  elsif p_action = 'relationship' then
    if choice_value = '' then
      raise exception 'Enter a name for this relationship.';
    end if;
    activities := coalesce(player_row.save_state -> 'relationships', '[]'::jsonb) ||
      jsonb_build_array(jsonb_build_object('name', choice_value, 'status', 'New contact', 'metAt', now()));
    update public.players
    set save_state = jsonb_set(coalesce(save_state, '{}'::jsonb), '{relationships}', activities, true),
        updated_at = now()
    where id = p_player_id;
    message_value := 'New contact added to your relationships.';
    result_value := jsonb_build_object('name', choice_value);

  elsif p_action = 'family_event' then
    if choice_value = '' then
      raise exception 'Enter a name for this family record.';
    end if;
    activities := coalesce(player_row.save_state -> 'family', '[]'::jsonb) ||
      jsonb_build_array(jsonb_build_object('name', choice_value, 'addedAt', now()));
    update public.players
    set save_state = jsonb_set(coalesce(save_state, '{}'::jsonb), '{family}', activities, true),
        updated_at = now()
    where id = p_player_id;
    message_value := 'Family record updated.';
    result_value := jsonb_build_object('name', choice_value);
  end if;

  return jsonb_build_object('message', message_value, 'result', result_value);
end;
$$;

revoke all on function public.initialize_syndicate_player() from public, anon, authenticated;
revoke all on function public.apply_account_interest(uuid) from public, anon, authenticated;
revoke all on function public.perform_game_action(uuid, text, numeric, text, uuid, text) from public, anon, authenticated;
grant execute on function public.apply_account_interest(uuid) to service_role;
grant execute on function public.perform_game_action(uuid, text, numeric, text, uuid, text) to service_role;

insert into public.game_news (headline, category) values
  ('A new season of stage auditions opens across the Garden City.', 'entertainment'),
  ('Small traders in Mile 1-3 Diobu report a stronger week at the markets.', 'economy'),
  ('Evening traffic slows near Trans Amadi as the shift change begins.', 'city');
