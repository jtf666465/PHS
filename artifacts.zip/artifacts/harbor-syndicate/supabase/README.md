# Supabase setup

The web game uses Supabase Auth. The API server uses a server-side Supabase service-role client for authoritative player data and game actions.

## One-time database setup

1. Open the Supabase project linked to this app.
2. Open **SQL Editor** and create a new query.
3. Copy the full contents of `schema.sql` into the query and run it.
4. Confirm the query completes before registering a player.

The script creates the player and bank tables, row-level security policies, the account-creation trigger, account interest handling, and the transactional game-action function. It does not copy or delete existing Supabase data.

## Required environment variable names

Configure these values in Replit Secrets or environment variables; do not put secret values in source control:

| Variable | Used by |
| --- | --- |
| `SUPABASE_URL` | API server |
| `SUPABASE_ANON_KEY` | API server authentication |
| `SUPABASE_SERVICE_ROLE_KEY` | API server only; never expose to the browser |
| `VITE_SUPABASE_URL` | Browser auth client |
| `VITE_SUPABASE_ANON_KEY` | Browser auth client |

The Vite-prefixed values are public Supabase project configuration. The service-role key must remain server-only.

## Email confirmation

If email confirmation is enabled in Supabase Auth, a newly registered player must confirm the email before signing in. The game will show a confirmation message after registration.
